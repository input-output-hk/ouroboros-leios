#!/usr/bin/env bash

set -eo pipefail

LOGFILE="$(date +%FT%T).log"

$HOME/bin/cardano-node run \
  --config $HOME/config/node.json \
  --topology $HOME/config/topology.yaml \
  --database-path $HOME/node.db \
  --socket-path $HOME/node.socket \
  --host-addr 0.0.0.0 \
  --port 3001 \
  +RTS -N4 -I0 -A16m -qg -qb --disable-delayed-os-memory-return -RTS \
| tee /dev/tty \
| tee "$LOGFILE" \
| ansifilter \
| grep --line-buffered -E 'cardano\.node\.(BlockFetchClient|ChainDB|ConnectionManager|Mempool|TxInbound|TxOutbound)' \
| gzip -9c \
> "$LOGFILE.gz"
