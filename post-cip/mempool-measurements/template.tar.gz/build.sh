#!/usr/bin/env bash

mkdir -p build bin node.db

nix build 'github:IntersectMBO/cardano-node?ref=10.5.1#cardano-node' -o build/cardano-node
nix build 'github:IntersectMBO/cardano-node?ref=10.5.1#cardano-cli' -o build/cardano-cli

ln -s ../build/cardano-node/bin/cardano-node bin/cardano-node
ln -s ../build/cardano-cli/bin/cardano-cli bin/cardano-cli

nix-env -iA nixos.ansifilter

sudo iptables -I INPUT -p tcp -m tcp --dport 3001 -m state --state NEW,ESTABLISHED -j nixos-fw-accept
