#!/usr/bin/env bash
# Render every figure in plots/ from data/*.tsv. Figures without data render as placeholders.
# Optional: TARGET_RB_MS=<ms> ./plot.sh draws the Praos regression target.
set -euo pipefail
cd "$(dirname "$0")"; . ./lib.sh; mkdir -p derived plots
F=$(margin f); TAU=$(margin tau)
gp() { gnuplot -e "$1" "$2"; }
placeholder() { gnuplot -e "out='plots/$1.svg'; ttl='$2'; src='$3'" gp/placeholder.gp; }
num() { [ "$1" = "-" ] && echo NaN || echo "$1"; }

# Ramp: join schedule with parameter caps
rows data/schedule.tsv | while read -r day date set timing phase status; do
  echo "$day $(param "$set" 3) $(param "$set" 5) $phase $status $set $timing"; done > derived/ramp.tsv
gnuplot gp/ramp.gp

# Certification window (analytic); fitted W from params.tsv when present
W0=$(awk -v h="$(param T0 7)" -v v="$(param T0 8)" -v d="$(param T0 9)" 'BEGIN{print (3*h+v+d)/1000}')
wfit() { [ "$(param "$1" 7)" = "-" ] && echo NaN || awk -v h="$(param "$1" 7)" -v v="$(param "$1" 8)" -v d="$(param "$1" 9)" 'BEGIN{print (3*h+v+d)/1000}'; }
gp "f=$F; S_M0=$(param M0 3); S_M1=$(param M1 3); S_M2=$(param M2 3); W_T0=$W0; Wf_M0=$(wfit M0); Wf_M1=$(wfit M1); Wf_M2=$(wfit M2)" gp/cert-window.gp

# Readiness fit and slack
if has_data data/eb.tsv && ./derive-timing.sh > derived/derive.log; then
  read -r A B C DR N R2 _ < <(rows derived/fit.tsv)
  gp "a=$A; b=$B; c=$C; d=$DR; n=$N; r2=$R2" gp/ready-fit.gp
  : > derived/slack.tsv; DAYS=""; NB=0
  for day in $(rows data/eb.tsv | awk '{print $1}' | sort -n | uniq); do
    read -r set tm < <(awk -v d="$day" '!/^#/ && $1==d {print $3, $4}' data/schedule.tsv)
    read -r h v df < <(timing "$set" "$tm")
    rows data/eb.tsv | awk -v d="$day" -v h="$h" -v v="$v" -v df="$df" '$1==d && $8!="-" {
      vs=3*h+v-$8; W=3*h+v+df; gs="-"
      if($9!="-" && $10!="-"){m=($9>$10)?$9:$10; gs=W-m}
      print vs, gs }' >> derived/slack.tsv
    printf "\n\n" >> derived/slack.tsv; DAYS="$DAYS $day"; NB=$((NB+1))
  done
  gp "n=$NB; days='${DAYS# }'" gp/slack-cdf.gp
else
  placeholder ready-fit "Vote readiness model" data/eb.tsv
  placeholder slack-cdf "Slack against the timing parameters in effect" data/eb.tsv
fi

# Validation time per hardware class: val = v0 + p*steps_G + q*refscript_kB
if has_data data/validation.tsv; then
  CL=$(rows data/validation.tsv | awk '{print $2}' | sort -u | tr '\n' ' '); NC=$(echo $CL | wc -w)
  printf "# class\tv0_ms\tms_per_Gstep\tms_per_refkB\tn\tR2\tflag\n" > derived/valfit.tsv
  : > derived/valfit-steps.tsv; : > derived/valfit-ref.tsv
  for c in $CL; do
    read -r V0 P Q N R2 FL < <(rows data/validation.tsv | awk -v c="$c" '$2==c{print $4, $3/1e9, $5/1000}' | awk -f lsq.awk)
    printf "%s\t%s\t%s\t%s\t%s\t%s\t%s\n" "$c" "$V0" "$P" "$Q" "$N" "$R2" "$FL" >> derived/valfit.tsv
    rows data/validation.tsv | awk -v c="$c" -v v0="$V0" -v p="$P" -v q="$Q" '$2==c{s=$3/1e9;r=$5/1000;n++;ss+=s;sr+=r;if(s>ms)ms=s;if(r>mr)mr=r}
      END{ printf "0 %g\n%g %g\n\n\n", v0+q*sr/n, ms, v0+p*ms+q*sr/n >> "derived/valfit-steps.tsv"
           printf "0 %g\n%g %g\n\n\n", v0+p*ss/n, mr, v0+p*ss/n+q*mr >> "derived/valfit-ref.tsv" }'
  done
  gp "classes='$CL'; nc=$NC" gp/validation.gp
else placeholder validation "EB validation time by hardware class" data/validation.tsv; fi

# Praos regression
if has_data data/rb.tsv; then
  rows data/rb.tsv | awk '{print $1, substr($3,2)+0, $5-$6, $7}' > derived/rb.tsv
  gp "target=${TARGET_RB_MS:-NaN}" gp/praos.gp
else placeholder praos "Praos regression" data/rb.tsv; fi

if has_data data/certrate.tsv; then gp "f=$F" gp/certrate.gp
else placeholder certrate "EB certification rate" data/certrate.tsv; fi

if has_data data/resources.tsv; then
  CL=$(rows data/resources.tsv | awk '{print $3}' | sort -u | tr '\n' ' ')
  gp "classes='$CL'; nc=$(echo $CL | wc -w)" gp/resources.gp
else placeholder resources "Node resources at saturation" data/resources.tsv; fi

if has_data data/adv-withhold.tsv || has_data data/adv-burst.tsv; then gp "tau=$TAU" gp/adversarial.gp
else placeholder adversarial "Adversarial scenarios" "data/adv-*.tsv"; fi
echo "plots written to plots/"
