# Ordinary least squares: z = a + sum_j c_j * x_j.
# Input lines: z x1 .. xk. Output: "a c1 .. ck n r2 flag".
# A regressor without variation is dropped (coefficient 0, named in flag).
{ n++; k = NF - 1; z[n] = $1; for (j = 1; j <= k; j++) x[n, j] = $(j + 1) }
END {
  if (n < k + 2) { s = "nan"; for (j = 1; j <= k; j++) s = s " nan"; print s, n, "nan", "too-few"; exit }
  flag = "ok"; m = 0
  for (j = 1; j <= k; j++) {
    s1 = 0; s2 = 0; for (i = 1; i <= n; i++) { s1 += x[i, j]; s2 += x[i, j] ^ 2 }
    v = s2 / n - (s1 / n) ^ 2
    if (v > 1e-12 * (1 + (s1 / n) ^ 2)) { m++; use[m] = j } else flag = flag "-drop" j
  }
  p = m + 1                                   # columns: intercept + used regressors
  for (r = 1; r <= p; r++) { for (c = 1; c <= p + 1; c++) M[r, c] = 0 }
  for (i = 1; i <= n; i++) {
    v1[1] = 1; for (r = 2; r <= p; r++) v1[r] = x[i, use[r - 1]]
    for (r = 1; r <= p; r++) { for (c = 1; c <= p; c++) M[r, c] += v1[r] * v1[c]; M[r, p + 1] += v1[r] * z[i] }
  }
  for (c = 1; c <= p; c++) {                  # Gaussian elimination, partial pivoting
    piv = c; for (r = c + 1; r <= p; r++) if ((M[r, c] < 0 ? -M[r, c] : M[r, c]) > (M[piv, c] < 0 ? -M[piv, c] : M[piv, c])) piv = r
    if (M[piv, c] == 0) { flag = flag "-singular"; for (r = 1; r <= p; r++) sol[r] = 0; break }
    for (cc = 1; cc <= p + 1; cc++) { t = M[c, cc]; M[c, cc] = M[piv, cc]; M[piv, cc] = t }
    for (r = 1; r <= p; r++) if (r != c) { f = M[r, c] / M[c, c]; for (cc = c; cc <= p + 1; cc++) M[r, cc] -= f * M[c, cc] }
  }
  for (r = 1; r <= p; r++) sol[r] = (M[r, r] == 0) ? 0 : M[r, p + 1] / M[r, r]
  for (j = 1; j <= k; j++) coef[j] = 0
  for (r = 2; r <= p; r++) coef[use[r - 1]] = sol[r]
  sz = 0; szz = 0; rr = 0
  for (i = 1; i <= n; i++) { pr = sol[1]; for (j = 1; j <= k; j++) pr += coef[j] * x[i, j]; rr += (z[i] - pr) ^ 2; sz += z[i]; szz += z[i] ^ 2 }
  vt = szz - sz * sz / n
  out = sprintf("%.6g", sol[1]); for (j = 1; j <= k; j++) out = out sprintf(" %.6g", coef[j])
  print out, n, sprintf("%.4f", (vt > 0) ? 1 - rr / vt : 0), flag
}
