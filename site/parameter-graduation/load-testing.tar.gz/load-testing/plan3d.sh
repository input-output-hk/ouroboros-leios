#!/usr/bin/env bash
# Graduation plans in (EB txs, Plutus steps, L_diff) with L_vote = L_diff - 3*L_hdr.
# Writes derived/plan3d.tsv (all derived protocol parameters per step) and plots/plan3d.svg.
# Feasibility surface = minimum L_diff, using the linear readiness model:
#   vote window  3*L_hdr + L_vote = L_diff  >= k * ready_tau(B, S)
#   gate         W = 2*L_diff               >= k * max(ready_tau + d99, closure_all(B))
#   floor        L_vote > 0
# Coefficients come from derived/fit.tsv when present, else data/model-illustrative.tsv.
# The interactive page samples the DeltaQ model instead; this script is the offline fallback.
set -euo pipefail
cd "$(dirname "$0")"; . ./lib.sh; mkdir -p derived plots
r() { awk -v k="$1" '$1==k{print $2}' data/ratios.tsv; }
m() { awk -v k="$1" '!/^#/ && $1==k{print $2}' data/model-illustrative.tsv; }
H=$(r hdr_ms); K=$(margin k)
if [ -s derived/fit.tsv ]; then
  read -r A B C _ _ _ R99 _ A2 B2 CR99 _ D99 _ < <(rows derived/fit.tsv); SRC="fitted"
  A=$(awk -v a="$A" -v r="$R99" 'BEGIN{print a+r}'); A2=$(awk -v a="$A2" -v r="$CR99" 'BEGIN{print a+r}')
else A=$(m a); B=$(m b); C=$(m c); A2=$(m a2); B2=$(m b2); D99=$(m d99); K=$(m k); SRC="illustrative"; fi
{ echo "# plan step L_hdr_ms L_vote_ms L_diff_ms EB_refs_B EB_txs_B plutus_mem plutus_steps refscript_B W_ms needs_ms feasible"
  rows data/plan3d.tsv | awk -v rr="$(r refs_per_closure)" -v mm="$(r mem_per_step)" -v rs="$(r refscript_per_Gstep)" -v h="$H" \
    -v a="$A" -v b="$B" -v c="$C" -v a2="$A2" -v b2="$B2" -v d="$D99" -v k="$K" '
    { kb=$3/1000; R=a+b*kb+c*$4; G=R+d; Cc=a2+b2*kb; if(Cc>G)G=Cc
      need=k*R; if(k*G/2>need)need=k*G/2; if(3*h+100>need)need=3*h+100
      printf "%s %s %d %d %d %d %d %.0f %.0f %.0f %d %.0f %s\n", $1, $2, h, $5-3*h, $5, int($3*rr+0.5), $3, $4*1e9*mm, $4*1e9, $4*rs, 2*$5, need, ($5>=need)?"yes":"no" }'
} > derived/plan3d.tsv
gnuplot -e "a=$A; b=$B; c=$C; a2=$A2; b2=$B2; d=$D99; k=$K; h=$H; src='$SRC'" gp/plan3d.gp
awk '{for(i=1;i<=NF;i++) printf "%-13s", $i; print ""}' derived/plan3d.tsv
