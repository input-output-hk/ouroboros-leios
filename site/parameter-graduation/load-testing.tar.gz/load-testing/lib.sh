# Shared helpers (sourced).
rows() { grep -v '^[[:space:]]*#' "$1" | awk 'NF>0'; }
has_data() { [ -n "$(rows "$1" | head -n1)" ]; }
# p-th percentile (0..1) of numbers on stdin; prints nan when empty
pct() { sort -g | awk -v p="$1" '{v[NR]=$1} END{if(NR==0){print "nan";exit} i=int(p*NR+0.999999); if(i<1)i=1; if(i>NR)i=NR; print v[i]}'; }
margin() { awk -v k="$1" '$1==k{print $2}' data/margins.tsv; }
param() { awk -v s="$1" -v c="$2" '!/^#/ && $1==s {print $c}' data/params.tsv; }
# timing for a set: fitted if present, else T0. prints "hdr vote diff"
timing() {
  if [ "$2" = "fit" ] && [ "$(param "$1" 7)" != "-" ]; then echo "$(param "$1" 7) $(param "$1" 8) $(param "$1" 9)"
  else echo "$(param T0 7) $(param T0 8) $(param T0 9)"; fi
}
