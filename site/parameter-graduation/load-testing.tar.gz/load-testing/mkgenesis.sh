#!/usr/bin/env bash
# Usage: ./mkgenesis.sh SET [T0|fit]  ->  genesis/SET/dijkstra-genesis.json
# Starts from genesis/base-dijkstra-genesis.json (pinned testnet genesis) and sets the Leios keys from data/params.tsv.
set -euo pipefail
cd "$(dirname "$0")"; . ./lib.sh
S=${1:?set}; TM=${2:-T0}
read -r H V D < <(timing "$S" "$TM")
mkdir -p "genesis/$S"
jq --argjson refs "$(param "$S" 2)" --argjson txs "$(param "$S" 3)" --argjson mem "$(param "$S" 4)" \
   --argjson steps "$(param "$S" 5)" --argjson rs "$(param "$S" 6)" --argjson h "$H" --argjson v "$V" --argjson d "$D" \
   '.maxEndorserBlockReferencesSize=$refs | .maxEndorserBlockTxsSize=$txs
    | .maxEndorserBlockExecutionUnits={memory:$mem, steps:$steps} | .maxRefScriptSizePerEndorserBlock=$rs
    | .leiosAnnouncementPeriodLength=$h | .leiosVotePeriodLength=$v | .leiosDiffusionPeriodLength=$d' \
   genesis/base-dijkstra-genesis.json > "genesis/$S/dijkstra-genesis.json"
echo "genesis/$S/dijkstra-genesis.json (timing $TM: $H/$V/$D ms)"
