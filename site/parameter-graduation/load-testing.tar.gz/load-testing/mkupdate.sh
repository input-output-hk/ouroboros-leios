#!/usr/bin/env bash
# Usage: ./mkupdate.sh SET [T0|fit]  ->  arguments for demo/dozen-devnet/propose-pparam-update.sh
# The proposal script checks each --key-value against `cardano-cli dijkstra governance action
# create-protocol-parameters-update --help` and fails early on a wrong name. The EB ex-units pair has no
# --key-value form; look up its flags with: ... --help | grep -i endorser
set -euo pipefail
cd "$(dirname "$0")"; . ./lib.sh
S=${1:?set}; TM=${2:-T0}
read -r H V D < <(timing "$S" "$TM")
echo "--key-value maxEndorserBlockReferencesSize=$(param "$S" 2) \\"
echo "--key-value maxEndorserBlockTxsSize=$(param "$S" 3) \\"
echo "--key-value maxRefScriptSizePerEndorserBlock=$(param "$S" 6) \\"
echo "--key-value leiosAnnouncementPeriodLength=$H \\"
echo "--key-value leiosVotePeriodLength=$V \\"
echo "--key-value leiosDiffusionPeriodLength=$D"
echo "# EB ex units: memory $(param "$S" 4), steps $(param "$S" 5)" >&2
