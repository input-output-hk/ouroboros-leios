# Analytic: certification opportunity and throughput bound vs the gate W = 3*L_hdr + L_vote + L_diff.
# Vars from plot.sh: f (1/s), S_M0, S_M1, S_M2 (bytes), W_T0 (s), Wf_M0, Wf_M1, Wf_M2 (s or NaN)
load 'gp/common.gp'
set output 'plots/cert-window.svg'
set title "Certification opportunity exp(-f*W) and EB throughput bound f*exp(-f*W)*S_EB-tx"
set xlabel "W = 3*L_hdr + L_vote + L_diff (s)"
set ylabel "Certification opportunity (%)"
set y2label "EB throughput bound (kB/s, log scale)"
set xrange [5:30]; set yrange [0:100]
set logscale y2; set y2range [1:1000]; set ytics nomirror
set y2tics ("1" 1, "2" 2, "5" 5, "10" 10, "20" 20, "50" 50, "100" 100, "200" 200, "500" 500, "1000" 1000)
set key top right
p(w) = 100*exp(-f*w)
t(w,S) = f*exp(-f*w)*S/1000
set arrow 1 from W_T0, graph 0 to W_T0, graph 1 nohead dt 2 lc rgb "#000000"
set label 1 sprintf("T0: W = %g s", W_T0) at W_T0, graph 0.04 offset 0.5,0
if (Wf_M0 == Wf_M0) { set arrow 2 from Wf_M0, graph 0 to Wf_M0, graph 1 nohead lc rgb "#E52321" ; set label 2 "M0 fit" at Wf_M0, graph 0.96 offset 0.5,0 tc rgb "#E52321" }
if (Wf_M1 == Wf_M1) { set arrow 3 from Wf_M1, graph 0 to Wf_M1, graph 1 nohead lc rgb "#EC641D" ; set label 3 "M1 fit" at Wf_M1, graph 0.90 offset 0.5,0 tc rgb "#EC641D" }
if (Wf_M2 == Wf_M2) { set arrow 4 from Wf_M2, graph 0 to Wf_M2, graph 1 nohead lc rgb "#2D5BFF" ; set label 4 "M2 fit" at Wf_M2, graph 0.84 offset 0.5,0 tc rgb "#2D5BFF" }
plot p(x) lt 3 title "opportunity", \
     t(x,S_M0) axes x1y2 lt 1 title "M0 bound", \
     t(x,S_M1) axes x1y2 lt 2 title "M1 bound", \
     t(x,S_M2) axes x1y2 lt 4 title "M2 bound", \
     f*90112/1000 axes x1y2 lt 3 dt 3 lw 1 title "Praos RB (90 kB)"
