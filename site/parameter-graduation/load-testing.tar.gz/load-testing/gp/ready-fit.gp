# Vars: a b c d (ms, ms/kB, ms/Gstep, ms/ref-kB), r2, n
load 'gp/common.gp'
set terminal svg size 1200,440 noenhanced
set output 'plots/ready-fit.svg'
set multiplot layout 1,3 title sprintf("Vote readiness: ready_tau = %.0f + %.3f*closure_kB + %.3f*steps_G + %.4f*refscript_kB  ms   (n = %d, R^2 = %.2f)", a, b, c, d, n, r2)
unset key
set ylabel "ready_tau (ms)"
set palette defined (0 "#f5c7c6", 1 "#E52321", 2 "#000000")
set xlabel "EB closure (kB)"; set cblabel "EB steps (G)"
plot 'data/eb.tsv' using ($5/1000):8:($6/1e9) with points pt 7 ps 0.5 lc palette
set xlabel "Referenced scripts (kB)"; set cblabel "EB closure (kB)"
plot 'data/eb.tsv' using ($12/1000):8:($5/1000) with points pt 7 ps 0.5 lc palette
unset colorbox
set xlabel "Predicted (ms)"; set ylabel "Measured (ms)"
plot 'data/eb.tsv' using (a + b*$5/1000 + c*$6/1e9 + d*$12/1000):8 with points pt 7 ps 0.5 lc rgb "#E52321", x with lines lt 3 dt 2 lw 1
unset multiplot
