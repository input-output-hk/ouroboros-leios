# Inputs: data/adv-withhold.tsv, data/adv-burst.tsv. Var: tau
load 'gp/common.gp'
set terminal svg size 1000,460 noenhanced
set output 'plots/adversarial.svg'
set multiplot layout 1,2 title "Adversarial scenarios"
sets = "M0 M2 X"
set key top right
set xlabel "Withheld stake (fraction of total)"; set xrange [0:0.5]
set ylabel "Certified / announced"; set yrange [0:1]
set arrow 1 from 1-tau, graph 0 to 1-tau, graph 1 nohead dt 2 lc rgb "#000000"
set label 1 "1 - tau" at 1-tau, graph 0.95 offset 0.5,0
plot for [i=1:3] 'data/adv-withhold.tsv' using (strcol(1) eq word(sets,i) ? $2 : 1/0):($4/$3) with linespoints lt i title word(sets,i)
unset arrow 1; unset label 1
set xlabel "EBs released in one burst"; set autoscale x; set autoscale y
set ylabel "Catch-up time (s)"
plot for [i=1:3] 'data/adv-burst.tsv' using (strcol(1) eq word(sets,i) ? $2 : 1/0):3 with linespoints lt i title word(sets,i)
unset multiplot
