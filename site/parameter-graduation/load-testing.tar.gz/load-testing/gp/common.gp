# Shared style. IO palette: Infrared, Dawn, black; secondaries for extra series.
set terminal svg size 900,460 dynamic font "Barlow,Helvetica,Arial,sans-serif,13" background rgb "white"
set termoption noenhanced
set datafile commentschars "#"
set datafile missing "-"
set border 3 lw 1 lc rgb "#222222"
set tics nomirror
set grid lc rgb "#e3e3e3" lw 1
set key top left box lc rgb "#cccccc" opaque
INFRARED = 0xE52321
DAWN     = 0xEC641D
INK      = 0x000000
GREY     = 0x9a9a9a
BLUE     = 0x2D5BFF
VIOLET   = 0x7A3CE0
GREEN    = 0x2EA44F
set linetype 1 lc rgb "#E52321" lw 2 pt 7 ps 0.8
set linetype 2 lc rgb "#EC641D" lw 2 pt 5 ps 0.8
set linetype 3 lc rgb "#000000" lw 2 pt 9 ps 0.8
set linetype 4 lc rgb "#2D5BFF" lw 2 pt 11 ps 0.8
set linetype 5 lc rgb "#7A3CE0" lw 2 pt 13 ps 0.8
set linetype 6 lc rgb "#2EA44F" lw 2 pt 3 ps 0.8
set linetype 7 lc rgb "#B8860B" lw 2 pt 15 ps 0.8
set linetype cycle 7
