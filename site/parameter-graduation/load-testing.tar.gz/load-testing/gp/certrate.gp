# Input: data/certrate.tsv
load 'gp/common.gp'
set output 'plots/certrate.svg'
set title "EB certification rate per day and load profile; crosses: exp(-f*W) for the W in effect"
set xlabel "Day"; set xrange [0.4:14.6]; set xtics 1
set ylabel "Certified / announced"; set yrange [0:1]
set key top right
pidx(s) = int(substr(s,2,2))
plot 'data/certrate.tsv' using 1:(exp(-f*$6/1000)) with points pt 1 ps 3 lw 2 lc rgb "#000000" title "expected", \
     for [p=0:6] 'data/certrate.tsv' using (pidx(strcol(3)) == p ? $1 + (p-3)*0.1 : 1/0):($5/$4) with points lt p+1 pt 7 title "L".p
