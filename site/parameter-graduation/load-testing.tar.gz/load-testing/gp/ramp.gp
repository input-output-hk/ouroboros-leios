# Planned parameter path per day. Input: derived/ramp.tsv (day txs_B steps phase status set timing)
load 'gp/common.gp'
set terminal svg size 900,520 noenhanced
set output 'plots/ramp.svg'
set title "Parameter path: EB txs (bars) and Plutus steps (line)"
set xlabel "Day"
set ylabel "EB txs (kB, log scale)"
set y2label "Plutus steps (G, log scale)"
set logscale y; set logscale y2
set yrange [100:20000]; set y2range [100:5000]
set ytics ("100" 100, "200" 200, "500" 500, "1000" 1000, "2000" 2000, "5000" 5000, "10000" 10000, "20000" 20000)
set y2tics ("100" 100, "200" 200, "500" 500, "1000" 1000, "2000" 2000, "5000" 5000)
set ytics nomirror
set xrange [0.4:14.6]; set xtics 1
set key outside bottom center horizontal maxcols 4 nobox
ymin = 100
col(p) = (p eq "up" ? INFRARED : (p eq "top" ? INK : (p eq "buffer" ? GREY : DAWN)))
set style fill solid 0.85 noborder
plot 'derived/ramp.tsv' using 1:($2/1000):($1-0.36):($1+0.36):(ymin):($2/1000):(col(strcol(4))) with boxxyerror lc rgb variable notitle, \
     ''                 using 1:($2/1000):(sprintf("%s", strcol(6))) with labels offset 0,0.8 font ",11" notitle, \
     ''                 using 1:($3/1e9) axes x1y2 with linespoints lt 3 lw 1.5 pt 7 ps 0.5 title "Plutus steps", \
     ''                 using 1:(strcol(5) eq "done" ? 120 : 1/0) with points lt 6 pt 7 ps 1.4 title "done", \
     ''                 using 1:(strcol(5) eq "running" ? 120 : 1/0) with points lt 4 pt 7 ps 1.4 title "running", \
     ''                 using 1:(strcol(5) eq "blocked" ? 120 : 1/0) with points lt 1 pt 2 ps 1.6 lw 3 title "blocked", \
     NaN with boxes lc rgb "#E52321" title "ramp up", \
     NaN with boxes lc rgb "#000000" title "top", \
     NaN with boxes lc rgb "#EC641D" title "step down, adversarial"
