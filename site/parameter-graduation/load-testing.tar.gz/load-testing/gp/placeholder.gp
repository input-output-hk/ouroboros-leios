# Usage: gnuplot -e "out='plots/x.svg'; ttl='...'; src='data/x.tsv'" gp/placeholder.gp
load 'gp/common.gp'
set output out
set title ttl
unset grid; unset key; unset tics; unset border
set xrange [0:1]; set yrange [0:1]
set label 1 sprintf("No data yet. Fill %s and run ./plot.sh", src) at 0.5,0.5 center tc rgb "#666666"
plot NaN notitle
