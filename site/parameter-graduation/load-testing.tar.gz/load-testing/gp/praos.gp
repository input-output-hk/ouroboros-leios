# Input: derived/rb.tsv (day profile_idx delta_p95_ms fork_rate). Var: target (ms or NaN)
load 'gp/common.gp'
set output 'plots/praos.svg'
set title "Praos regression: RB diffusion p95 minus EB-free baseline"
set xlabel "Day"; set xrange [0.4:14.6]; set xtics 1
set ylabel "Delta RB p95 (ms)"
set key top left
if (target == target) { set arrow 1 from graph 0, first target to graph 1, first target nohead lc rgb "#E52321" dt 2 ; set label 1 "target" at graph 0.01, first target offset 0,0.6 tc rgb "#E52321" }
plot for [p=0:6] 'derived/rb.tsv' using ($2 == p ? $1 + (p-3)*0.1 : 1/0):3 with points lt p+1 pt 7 title "L".p
