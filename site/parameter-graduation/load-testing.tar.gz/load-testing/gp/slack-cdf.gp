# Input: derived/slack.tsv, one block per day: vote_slack_ms gate_slack_ms. Vars: n, days (string)
load 'gp/common.gp'
set terminal svg size 1000,460 noenhanced
set output 'plots/slack-cdf.svg'
set multiplot layout 1,2 title "Slack against the timing parameters in effect (negative = missed)"
set ylabel "Fraction of EBs"; set yrange [0:1]; set xrange [*<0:0<*]
set key bottom right
set arrow 1 from first 0, graph 0 to first 0, graph 1 nohead lc rgb "#000000" dt 2
set xlabel "3*L_hdr + L_vote - ready_tau (ms)"
plot for [i=0:n-1] 'derived/slack.tsv' index i using 1:(1) smooth cnormal lt (i%6)+1 title "day ".word(days,i+1)
set xlabel "W - max(quorum, closure_all) (ms)"
plot for [i=0:n-1] 'derived/slack.tsv' index i using 2:(1) smooth cnormal lt (i%6)+1 title "day ".word(days,i+1)
unset multiplot
