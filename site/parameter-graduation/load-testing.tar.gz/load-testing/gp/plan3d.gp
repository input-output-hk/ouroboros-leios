# Vars: a b c a2 b2 d k h (ms), src. Input: derived/plan3d.tsv (plan step L_hdr L_vote L_diff refs txs mem steps refscript W needs feasible)
load 'gp/common.gp'
set terminal svg size 1400,640 noenhanced
set output 'plots/plan3d.svg'
set multiplot title sprintf("Graduation plans in (EB txs, Plutus steps, L_diff); surface: minimum L_diff with L_vote = L_diff - 3*L_hdr (%s model, k = %.1f)", src, k)
set logscale xy
set xrange [100:12000]; set yrange [100:2000]; set zrange [3:17]
set xlabel "EB txs (kB, log scale)" rotate parallel offset 0,-1
set ylabel "Plutus steps (G, log scale)" rotate parallel offset 0,-1
set zlabel "L_diff (s)" rotate parallel
set xtics ("100" 100, "200" 200, "500" 500, "1000" 1000, "2000" 2000, "5000" 5000, "10000" 10000) offset 0,-0.5
set ytics ("100" 100, "200" 200, "500" 500, "1000" 1000, "2000" 2000)
set ztics 2
set ticslevel 0
set view 62, 32, 1, 1.05
set grid x y z vertical lc rgb "#e3e3e3"
set key at screen 0.56, screen 0.90 right top box opaque
set origin 0,0; set size 0.6,0.95
set isosamples 28, 28; set samples 28, 28
fl = (3*h + 100)/1000.0
gt(x,y)  = (a + b*x + c*y + d > a2 + b2*x) ? (a + b*x + c*y + d) : (a2 + b2*x)
r1(x,y)  = k*(a + b*x + c*y)/1000.0
r2(x,y)  = k*gt(x,y)/2000.0
req(x,y) = (r1(x,y) > r2(x,y) ? (r1(x,y) > fl ? r1(x,y) : fl) : (r2(x,y) > fl ? r2(x,y) : fl))
set pm3d at s implicit noborder
set palette defined (0 "#fde9e8", 0.5 "#f19a96", 1 "#E52321")
set cbrange [3:17]; unset colorbox
set style fill transparent solid 0.55
pc(p) = (p eq "dojo" ? 0x7A3CE0 : INFRARED)
splot req(x,y) with pm3d notitle, \
      'derived/plan3d.tsv' using ($7/1000):($9/1e9):(3):(pc(strcol(1))) with points pt 6 ps 1.0 lc rgb variable notitle, \
      ''                   using ($7/1000):($9/1e9):($5/1000):(pc(strcol(1))) with impulses lw 1 dt 2 lc rgb variable notitle, \
      ''                   using ($7/1000):($9/1e9):($5/1000):(pc(strcol(1))) with points pt 7 ps 1.4 lc rgb variable notitle, \
      ''                   using ($7/1000):($9/1e9):($5/1000):(strcol(2)) with labels offset 1.2,0.8 left font ",11" notitle, \
      ''                   using ($7/1000):($9/1e9):(strcol(1) eq "dojo" ? $5/1000 : 1/0) with lines lw 2.5 lc rgb "#7A3CE0" title "Musashi dojo Fire phase", \
      ''                   using ($7/1000):($9/1e9):(strcol(1) eq "mainnet" ? $5/1000 : 1/0) with lines lw 2.5 lc rgb "#E52321" title "mainnet milestones", \
      NaN with pm3d lc rgb "#f19a96" title "minimum L_diff (feasibility surface)"

# Right: top view with contours of the minimum L_diff
unset pm3d; unset zlabel; unset ztics; unset grid; set grid lc rgb "#e3e3e3"; set style fill solid 1.0
set xlabel norotate offset 0,0; set ylabel norotate offset 0,0
set origin 0.6,0.05; set size 0.4,0.85
set logscale xy; set xrange [100:12000]; set yrange [100:2000]
set xtics ("100" 100, "200" 200, "500" 500, "1000" 1000, "2000" 2000, "5000" 5000, "10000" 10000); set ytics ("100" 100, "200" 200, "500" 500, "1000" 1000, "2000" 2000)
set xlabel "EB txs (kB, log scale)" norotate offset 0,0; set ylabel "Plutus steps (G, log scale)" rotate by 90 offset 0,0
set xtics offset 0,0
set title "Top view: contours of minimum L_diff (s)"
set view map; set surface; set contour base
set autoscale z
set cntrparam firstlinetype 21
do for [i=21:28] { set linetype i lc rgb "#E52321" lw 1.2 dt 1 }
set cntrparam levels discrete 4, 5, 7, 9, 11, 13, 15
set cntrlabel format "%.0f s" font ",10" start 5 interval 60
set isosamples 60, 60; set samples 60, 60
unset key
splot req(x,y) nosurface with lines notitle, \
      req(x,y) nosurface with labels boxed notitle, \
      'derived/plan3d.tsv' using ($7/1000):($9/1e9):(strcol(1) eq "dojo" ? 0 : 1/0) with lines lw 2 lc rgb "#7A3CE0" nocontour notitle, \
      ''                   using ($7/1000):($9/1e9):(strcol(1) eq "mainnet" ? 0 : 1/0) with lines lw 2 lc rgb "#E52321" nocontour notitle, \
      ''                   using ($7/1000):($9/1e9):(0):(pc(strcol(1))) with points pt 7 ps 1.2 lc rgb variable nocontour notitle, \
      ''                   using ($7/1000):($9/1e9):(0):(sprintf("%s %.1f s", strcol(2), $5/1000)) with labels offset 0,1 font ",10" nocontour notitle
unset multiplot
