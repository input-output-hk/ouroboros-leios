# Input: data/resources.tsv. Vars: classes, nc
load 'gp/common.gp'
set terminal svg size 1000,460 noenhanced
set output 'plots/resources.svg'
set multiplot layout 1,2 title "Node resources at saturation, p95 by hardware class"
set xlabel "Day"; set xrange [0.4:14.6]; set xtics 2
set key top left
set ylabel "Egress (Mbit/s)"
plot for [i=1:nc] 'data/resources.tsv' using (strcol(3) eq word(classes,i) ? $1 : 1/0):4 with points lt i title word(classes,i)
set ylabel "CPU (%)"
plot for [i=1:nc] 'data/resources.tsv' using (strcol(3) eq word(classes,i) ? $1 : 1/0):5 with points lt i title word(classes,i)
unset multiplot
