# Inputs: data/validation.tsv, derived/valfit.tsv (class v0_ms ms_per_Gstep ms_per_refkB n), derived/valfit-*.tsv lines.
# Vars: classes, nc
load 'gp/common.gp'
set terminal svg size 1000,460 noenhanced
set output 'plots/validation.svg'
set multiplot layout 1,2 title "EB validation time by hardware class (TraceLeiosEbValidated); lines: fit with the other term at its class mean"
set ylabel "Validation (ms)"
set key top left
set xlabel "EB steps (G)"
plot for [i=1:nc] 'data/validation.tsv' using (strcol(2) eq word(classes,i) ? $3/1e9 : 1/0):4 with points lt i pt 7 ps 0.4 title word(classes,i), \
     for [i=0:nc-1] 'derived/valfit-steps.tsv' index i using 1:2 with lines lt i+1 lw 2 notitle
set xlabel "Referenced scripts (kB)"
plot for [i=1:nc] 'data/validation.tsv' using (strcol(2) eq word(classes,i) ? $5/1000 : 1/0):4 with points lt i pt 7 ps 0.4 title word(classes,i), \
     for [i=0:nc-1] 'derived/valfit-ref.tsv' index i using 1:2 with lines lt i+1 lw 2 notitle
unset multiplot
