#!/usr/bin/env bash
# Fit the readiness and diffusion models on data/eb.tsv and derive timing parameters for every set.
# Writes derived/fit.tsv and derived/timing-derived.tsv; prints a summary. Copy chosen values into data/params.tsv.
set -euo pipefail
cd "$(dirname "$0")"; . ./lib.sh; mkdir -p derived
has_data data/eb.tsv || { echo "data/eb.tsv has no rows yet"; exit 1; }
K=$(margin k); AH=$(margin adv_hdr_ms); AV=$(margin adv_vote_ms); AD=$(margin adv_diff_ms); RND=$(margin round_ms); F=$(margin f)

# ready_tau = a + b*closure_kB + c*steps_G + d*refscript_kB
read -r A B C DR N R2 FLAG < <(rows data/eb.tsv | awk '$8!="-"{print $8, $5/1000, $6/1e9, $12/1000}' | awk -f lsq.awk)
RES99=$(rows data/eb.tsv | awk -v a="$A" -v b="$B" -v c="$C" -v d="$DR" '$8!="-"{print $8-(a+b*$5/1000+c*$6/1e9+d*$12/1000)}' | pct 0.99)
# closure_all = a2 + b2*closure_kB
read -r A2 B2 _ _ _ < <(rows data/eb.tsv | awk '$10!="-"{print $10, $5/1000}' | awk -f lsq.awk)
CRES99=$(rows data/eb.tsv | awk -v a="$A2" -v b="$B2" '$10!="-"{print $10-(a+b*$5/1000)}' | pct 0.99)
HDR99=$(rows data/eb.tsv | awk '$7!="-"{print $7}' | pct 0.99)
D99=$(rows data/eb.tsv | awk '$8!="-" && $9!="-"{print $9-$8}' | pct 0.99)
read -r MAXB MAXS MAXR < <(rows data/eb.tsv | awk '{if($5>b)b=$5; if($6>s)s=$6; if($12>r)r=$12} END{print b+0, s+0, r+0}')

printf "# a_ms\tb_ms_per_kB\tc_ms_per_Gstep\td_ms_per_refkB\tn\tR2\tres99_ms\tflag\ta2_ms\tb2_ms_per_kB\tcres99_ms\thdr99_ms\td99_ms\tmax_B\tmax_steps\tmax_ref_B\n" > derived/fit.tsv
printf "%s\t" "$A" "$B" "$C" "$DR" "$N" "$R2" "$RES99" "$FLAG" "$A2" "$B2" "$CRES99" "$HDR99" "$D99" "$MAXB" "$MAXS" >> derived/fit.tsv
echo "$MAXR" >> derived/fit.tsv

{ echo "# set  R_ms  C_ms  hdr_ms  vote_ms  diff_ms  W_ms  cert_opportunity  eb_kB_per_s  note"
  for s in M0 M1 M2 X; do
    awk -v s="$s" -v Bc="$(param $s 3)" -v Sc="$(param $s 5)" -v Rc="$(param $s 6)" \
        -v a="$A" -v b="$B" -v c="$C" -v d="$DR" -v r="$RES99" \
        -v a2="$A2" -v b2="$B2" -v cr="$CRES99" -v h="$HDR99" -v dl="$D99" -v k="$K" -v ah="$AH" -v av="$AV" -v ad="$AD" \
        -v rnd="$RND" -v f="$F" -v mb="$MAXB" -v ms="$MAXS" -v mr="$MAXR" 'function up(x){return int((x+rnd-1)/rnd)*rnd}
      function nz(x){return (x=="nan"||x=="")?0:x}
      BEGIN{ R=nz(a)+nz(b)*Bc/1000+nz(c)*Sc/1e9+nz(d)*Rc/1000+nz(r); C=nz(a2)+nz(b2)*Bc/1000+nz(cr)
        L1=up(k*nz(h)+ah); ve=up(k*R+av); L2=ve-3*L1; if(L2<rnd)L2=rnd
        g=R+nz(dl); if(C>g)g=C; ge=up(k*g+ad); L3=ge-3*L1-L2; if(L3<rnd)L3=rnd
        W=3*L1+L2+L3; P=exp(-f*W/1000)
        note=(Bc>1.1*mb||Sc>1.1*ms||Rc>1.1*mr)?"extrapolated":"in-range"
        printf "%s\t%.0f\t%.0f\t%d\t%d\t%d\t%d\t%.3f\t%.1f\t%s\n",s,R,C,L1,L2,L3,W,P,f*P*Bc/1000,note }'
  done; } > derived/timing-derived.tsv
echo "ready_tau model: a=$A ms, b=$B ms/kB, c=$C ms/Gstep, d=$DR ms/ref-kB (n=$N, R2=$R2, $FLAG), residual p99=$RES99 ms"
echo "closure_all model: a2=$A2 ms, b2=$B2 ms/kB, residual p99=$CRES99 ms; header p99=$HDR99 ms; vote lag p99=$D99 ms"
awk '{for(i=1;i<=NF;i++) printf "%-18s", $i; print ""}' derived/timing-derived.tsv
